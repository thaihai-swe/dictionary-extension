(function(){"use strict";var vn=Object.defineProperty;var Ln=(A,y,b)=>y in A?vn(A,y,{enumerable:!0,configurable:!0,writable:!0,value:b}):A[y]=b;var D=(A,y,b)=>Ln(A,typeof y!="symbol"?y+"":y,b);var ke,Ae,E,Pe,w;function A(e){return e}const y=800,b=6e3,et=6,we="p, li, blockquote, td, th, figcaption, dd, dt, h1, h2, h3, h4, h5, h6, pre",tt="p, li, td, th, blockquote, figcaption, dd, dt, h1, h2, h3, h4, h5, h6, pre, article, section, main, [role='article'], div";function oe(e){const t=String(e||"").replace(/\s+/g," ").trim();return t?t.length<=y?t:`${t.slice(0,y).trim()}\u2026`:""}function g(e){return String(e||"").replace(/\s+/g," ").trim()}function ae(e,t){const n=g(e),i=g(String(t||""));return!i||n&&i.toLowerCase()===n.toLowerCase()?!1:i.length>n.length}function nt(e){return String(e||"").replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}const it=/^[\x00-\x7F]+$/,rt=20,x=new Map;function ot(e){const t=String(e||"").replace(/\s+/g," ").trim();if(!t)return null;const n=x.get(t);if(n)return x.delete(t),x.set(t,n),n;const i=nt(t).replace(/ /g,"\\s+"),o=it.test(t)?new RegExp(`(^|[^A-Za-z0-9_])${i}(?=$|[^A-Za-z0-9_])`,"i"):new RegExp(`(^|[^\\p{L}\\p{N}_])${i}(?=$|[^\\p{L}\\p{N}_])`,"iu");for(x.set(t,o);x.size>rt;){const a=x.keys().next().value;if(!a)break;x.delete(a)}return o}function at(e,t){return e[t]==="."&&/\d/.test(e[t-1]||"")&&/\d/.test(e[t+1]||"")}const st=new Set(["mr","mrs","ms","dr","prof","sr","jr","st","vs","etc","inc","ltd","vol","fig"]);function lt(e,t){if(e[t]!==".")return!1;let n=t;for(;n>0&&/[A-Za-z]/.test(e[n-1]);)n-=1;const i=e.slice(n,t);return i?i.length===1?!0:st.has(i.toLowerCase()):!1}function G(e,t){let n=t+1;for(;n<e.length&&/[.!?。！？]/.test(e[n]);)n+=1;for(;n<e.length&&/["'”’»)]/.test(e[n]);)n+=1;return n}function se(e,t){const n=e[t];if(!n||!/[.!?。！？]/.test(n))return!1;if(/[。！？]/.test(n))return!0;if(at(e,t)||lt(e,t))return!1;let i=G(e,t);if(i>=e.length)return!0;if(!/\s/.test(e[i]))return!1;for(;i<e.length&&/\s/.test(e[i]);)i+=1;return i>=e.length||/["'“‘(\[]/.test(e[i])||/[\p{Lu}\p{N}]/u.test(e[i])}function ct(e){const t=g(e);if(!t)return[];const n=[];let i=0;for(let a=0;a<t.length;a+=1){if(!se(t,a))continue;const s=G(t,a),p=t.slice(i,s).trim();p&&n.push(p),i=s,a=s-1}const o=t.slice(i).trim();return o&&n.push(o),n}function N(e,t){const n=g(e),i=g(t);if(!n||!i)return!1;const o=ot(i);return o!=null&&o.test(n)?!0:n.toLowerCase().includes(i.toLowerCase())}function ut(e,t){const n=String(e||"");if(!n.trim())return"";const i=Math.max(0,Math.min(Number(t)||0,n.length));let o=0,a=n.length;for(let s=i-1;s>=0;s-=1)if(se(n,s)){o=G(n,s);break}for(let s=i;s<n.length;s+=1)if(se(n,s)){a=G(n,s);break}return g(n.slice(o,a))}function dt(e,t){if(!N(e,t))return"";const n=ct(e).find(o=>N(o,t));if(n)return n;const i=g(e);return N(i,t)?i:""}function Y(e,t=b){return String(e||"").slice(0,t).replace(/[\u00ad\u200b\u200c\u200d]/g,"").replace(/([A-Za-zÀ-ɏ]+)-\s*\r?\n\s*([A-Za-zÀ-ɏ]+)/g,"$1$2").replace(/\s+/g," ")}function be(e,t=b,n=""){if(!e)return"";const i=String(e.textContent||""),o=g(n);if(o&&i.length>t){const a=i.toLowerCase().indexOf(o.toLowerCase());if(a>=0){const s=Math.max(0,a-Math.floor(t/2));return Y(i.slice(s,s+t),t)}}return Y(i,t)}function ht(e,t){try{const n=t.cloneRange();return n.selectNodeContents(e),n.setEnd(t.startContainer,t.startOffset),n.toString().length}catch{return-1}}function pt(e,t,n=2e3){const i=ht(e,t);if(i<0)return null;const o=String(e.textContent||"");if(!o)return null;const a=Math.max(0,i-n),s=Math.min(o.length,i+n),p=Y(o.slice(a,i),n),m=Y(o.slice(a,s),n*2);return{text:m,offset:Math.min(p.length,m.length)}}function gt(e){return e?e.nodeType===Node.ELEMENT_NODE?e:e.parentElement:null}function ft(e){return/[.!?。！？]["'”’»)]*$/.test(g(e))}function mt(e,t){return ft(e)?!0:typeof t.matches=="function"&&t.matches(we)?g(be(t))===g(e):!1}function yt(e,t,n){const i=pt(e,t),o=g((i==null?void 0:i.text)||be(e));if(!o)return"";if(i&&i.offset>=0){const s=ut(i.text,i.offset);if(ae(n,s)&&N(s,n))return oe(s)}const a=dt(o,n);return ae(n,a)?oe(a):ae(n,o)&&N(o,n)?oe(o):""}function wt(e,t){const n=gt(e.commonAncestorContainer);if(!n||typeof n.closest!="function")return"";let i=n.closest(we)||n.closest(tt)||n,o=0,a="";for(;i&&o<et;){const s=yt(i,e,t);if(s){if(mt(s,i))return s;s.length>a.length&&(a=s)}if(i===document.body||i===document.documentElement)break;i=i.parentElement,o+=1}return a}function bt(e,t,n=""){const i=g(n),o=(()=>{if(!e||e.rangeCount<=0)return null;try{return e.getRangeAt(0)}catch{return null}})(),a=g((o==null?void 0:o.toString())||(e==null?void 0:e.toString())||"");return o&&(!i||a===i||!a)?o:t||o}function xt(e,t=!1,n){const i=String(e||"").trim();if(!i||t)return{context:"",source:"",confidence:"none"};try{const o=typeof window<"u"?window.getSelection():null,a=bt(o,n,i);if(!a)return{context:"",source:"",confidence:"none"};const s=g(a.toString()||(o==null?void 0:o.toString())||""),p=g(i);if(s&&s!==p)return{context:"",source:"",confidence:"none"};const m=wt(a,i);return m?{context:m,source:"selection",confidence:"exact"}:{context:"",source:"",confidence:"none"}}catch{return{context:"",source:"",confidence:"none"}}}const Et="LOOKUP_TEXT",St="CANCEL_LOOKUP";function le(e="req"){return`${e}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,8)}`}function vt(){return"dictionary"}function P(e){var n,i;const t=e instanceof Error?e.message:String(e||"");if(/Extension context invalidated|Context is invalidated|can't access dead object/i.test(t))return!0;try{return typeof chrome<"u"&&!((n=chrome.runtime)!=null&&n.id)&&typeof((i=chrome.runtime)==null?void 0:i.sendMessage)=="function"}catch{return!0}}function ce(e="Extension runtime is unavailable."){var t,n;try{return((n=(t=chrome.runtime)==null?void 0:t.lastError)==null?void 0:n.message)||e}catch{return e}}function ue(){return new Error("Extension runtime is unavailable.")}const de={isAvailable(){var e;try{return typeof chrome<"u"&&typeof((e=chrome.runtime)==null?void 0:e.sendMessage)=="function"&&!P()}catch{return!1}},send(e){return de.isAvailable()?new Promise((t,n)=>{try{chrome.runtime.sendMessage(e,i=>{const o=ce("");if(o){n(new Error(o));return}t(i||{ok:!1,error:"Empty runtime response."})})}catch(i){n(P(i)?ue():i instanceof Error?i:ue())}}):Promise.reject(ue())},sendNoWait(e){if(de.isAvailable())try{chrome.runtime.sendMessage(e,()=>{ce("")})}catch{}}};function Lt(e){return de.send(e)}function Tt(e,t="Request failed."){if(!(e!=null&&e.ok)){const n=new Error((e==null?void 0:e.error)||t);throw n.aborted=/abort/i.test(String((e==null?void 0:e.error)||"")),n}return e.result}async function kt(e){const t=e.requestId||le("dict"),n=await Lt({type:Et,payload:{...e,requestId:t}});return Tt(n,`No dictionary definition found for "${e.text}".`)}function At(e,t){var n;if(!(typeof chrome>"u"||typeof((n=chrome.runtime)==null?void 0:n.sendMessage)!="function"||P()))try{chrome.runtime.sendMessage({type:St,payload:{scope:e,requestId:t}},()=>{ce("")})}catch{}}function Pt(e){At(vt(),e)}const he=new Map;function Ct(e){const t=e.requestId||le("dict"),n=he.get(t);if(n)return n;const i=kt({...e,requestId:t}).finally(()=>{he.delete(t)});return he.set(t,i),i}const Mt=["default",...["explain_in_context","grammar","collocations","sentence_breakdown","confusables","rephrase"]];new Set(Mt);const _t=`Act as an expert lexicographer and language educator. Provide a focused, educational breakdown of "{{str}}".

Use simple, high-frequency vocabulary in the Oxford Learner's Dictionaries style.

Language policy:
{{languagePolicy}}

Formatting:
- {{markdownL3}}
- Do not include a synonyms list, antonyms list, or memory aids; those are covered elsewhere.

Start with a short untitled intro: **{{str}}** [IPA pronunciation] *part of speech*, then a concise Oxford-style definition with no introductory phrases.

### Senses & Meanings
List the primary senses as numbered bullets in this exact format:
1. *(pos)* English definition \u2014 {{targetLang}} gloss
Use one bullet per sense. Mark the sense that matches the surrounding context with **in context** after the gloss when context is present. Limit to 4 senses.

### Translation & Meaning
Provide accurate, natural translation(s) of "{{str}}" into {{targetLang}}. If the word has distinct primary senses or parts of speech, list each with its corresponding translation and a brief explanation in {{targetLang}}. Put the translation only in this section.

### Usage Note
Explain nuance, connotation, or register in 1-3 sentences. Do not list word-family forms, collocations, confusable words, or learner mistakes here.

### Example Sentences
Give 2 realistic examples. For each example use exactly this shape:
{{bilingualExampleShape}}
Never put English and the translation on the same visual style or the same line. The first blockquote is English only; the second blockquote is the {{targetLang}} translation only.

### Deep Understanding
Give the etymology or origin and subtle pragmatic notes for this sense in 1-2 short paragraphs.
Do not list related forms, derivatives, collocations, confusable words, or learner mistakes.
`,It=`Explain the selected text in its surrounding context for a language learner.
Selected text: "{{str}}"
Target language: {{targetLang}}
Surrounding context:
"""
{{context}}
"""

Language policy:
{{languagePolicy}}

Formatting:
- Keep the answer compact and scannable. Do not add a separate translation section or repeat the plain summary.
- {{markdownL3}}
- Do not rephrase the entire context sentence; whole-sentence rewrites belong to Rephrase.
- Do not decompose the whole sentence into clauses; that belongs to Sentence Breakdown.
- Do not list word-family forms, collocations, confusable pairs, or learner mistakes.

### Meaning in Context
Explain what "{{str}}" means specifically in this surrounding sentence, including its contextual translation into {{targetLang}}.

### Role & Quick Test
State the exact grammatical job of "{{str}}" in this sentence in one short sentence. Then give a 1-line rule of thumb or substitution test a learner can use to verify the choice (for example: "If you can replace it with 'influence', use affect").

### Direct Substitutions
Provide 2-3 natural synonyms or phrases that could directly replace "{{str}}" in this specific sentence without altering grammatical structure, each with a brief {{targetLang}} gloss.

### Nuance Lost
Explain in 1-2 sentences what tone, emphasis, or subtle nuance is lost if replaced by a plain synonym.
`,Rt=`Analyze the grammatical structure and syntactic slots of the selected text for a language learner.
Selected text: "{{str}}"
Target language: {{targetLang}}
Optional context:
"""
{{context}}
"""

Language policy:
{{languagePolicy}}

Formatting:
- {{markdownL3}}
- Do not include a separate Translation, Summary, or Formality & Tone section.
- Do not decompose the whole sentence into a clause table; that belongs to Sentence Breakdown.
- {{lexicalProfileHeadingBan}}

Include these sections:
### Syntactic Breakdown
Identify the part of speech, grammatical slot / syntactic role in the sentence (e.g. subject complement, transitive verb head, modifier), and dependency relations. If formality or register changes the slot, mention it in one clause here. Do not add a separate heading for formality.

### Pattern Rules
List 1-2 governing syntactic rules or clause patterns for this structure. For each rule, give the pattern formula or definition, then immediately 1 example that illustrates that specific rule. Do not add a separate Short Examples heading. Use this shape for every rule:

- **Pattern formula**: one-sentence definition of the rule
{{bilingualExampleShape}}
`,Ot=`Compare and contrast the confusable terms or query "{{str}}" for a language learner.
Target language: {{targetLang}}
Optional context:
"""
{{context}}
"""

Language policy:
{{languagePolicy}}

Formatting:
- {{markdownL3}}
- Do not rewrite the sentence in multiple styles; that belongs to Rephrase.
- Do not list word-family forms, learner mistakes, or a full dictionary definition.

### Core Distinction
Give a 2-sentence rule of thumb explaining the fundamental difference in meaning, register, or grammatical class.

### Comparison Matrix
Compare the terms across 2-3 key dimensions (Function/Meaning, Typical Usage/Register, Common Trap).

### Collocation Divergence
Show 2 distinct natural collocations or phrases for each term to illustrate correct usage.

### Minimal Pairs & Examples
Provide 2 minimal-pair sentence comparisons demonstrating when to choose one over the other. For each pair, give two contrasting English sentences as consecutive blockquotes, then a one-line explanation of the contrast:
> English sentence using the first term
> English sentence using the second term
Then one short sentence explaining the difference.
`,Dt=`Rephrase the supplied text or sentence for an English language learner across three distinct stylistic targets.
Original text: "{{sentence}}"
Target language for explanations: {{targetLang}}

Language policy:
{{languagePolicy}}

Formatting:
- Use only Markdown headings at level 3 (###) and blockquotes. Do not use HTML or code fences.
- Do not add a dictionary definition, grammar analysis, collocations, confusable comparison, or sentence breakdown. Only the three rewrite styles.

### Simplified Version
> Rewritten sentence using Oxford 3000 / A2-B1 high-frequency vocabulary.
Brief note in {{targetLang}} explaining why this is easier to read.

### Academic & Formal
> Rewritten sentence suitable for formal essays, academic publications, or business correspondence.
Brief note in {{targetLang}} explaining the elevated register and syntactic choices.

### Native & Idiomatic
> Rewritten sentence using natural native collocations or conversational idioms.
Brief note in {{targetLang}} on the idiomatic flavor.
`,Nt=`Analyze the supplied sentence for an English language learner.
Selected query: {{str}}
Sentence to analyze:
"""
{{sentence}}
"""
Target language: {{targetLang}}

Language policy:
{{languagePolicy}}

Return only one valid JSON object. Do not wrap it in Markdown or add commentary.
Use this exact shape:
{
  "sentence": "the sentence being analyzed",
  "translation": "translation into the target language",
  "parts": [{"text": "exact text", "role": "subject|verb phrase|object|modifier|clause|other", "explanation": "short English explanation"}],
  "phrases": [{"text": "exact phrase from the sentence", "type": "phrasal_verb|idiom|collocation|fixed_expression", "meaning": "learner-friendly English meaning", "role": "grammatical function", "example": "short example"}]
}

Rules:
- Analyze only the supplied sentence; never invent surrounding text.
- Write grammatical role explanations and phrase meanings in English. Provide the full-sentence translation in {{targetLang}}.
- Identify the selected query when it appears in the sentence.
- Include only phrases that appear exactly or nearly exactly in the supplied sentence.
- Return an empty phrases array when no phrasal verb, idiom, collocation, or fixed expression is present.
- Do not return learner mistakes, usage notes, or extra commentary; Grammar owns those.
- Keep each explanation concise and suitable for a language learner.
`,Ut=`Explore the phrase, idiom, phrasal verb, collocation, or expression "{{str}}" for a language learner.
Target language: {{targetLang}}
Optional context:
"""
{{context}}
"""

Language policy:
{{languagePolicy}}

Formatting:
- Keep the answer concise, accurate, and practical. Use level-3 Markdown headings (###) and bullet lists. Do not use code fences or HTML.
- Do not invent context. If the expression is not idiomatic, explain its preposition patterns and literal usage.
- Do not rewrite the whole sentence in multiple styles; that belongs to Rephrase.
- {{lexicalProfileHeadingBan}}

### Core Meaning
Give the natural meaning and translation into {{targetLang}} first, then explain any literal meaning, image, or word partnerships. If register changes whether a learner should use the expression, add one line here. Do not add a separate heading for register.

### Grammar & Patterns
Show the grammatical pattern, separability for phrasal verbs, required preposition combinations (e.g. depend + on, fond + of), and common variations.

### Natural Examples
Give 2-3 realistic example sentences in context. For each example use exactly this shape:
{{bilingualExampleShape}}
`,Ft=`Explain the multi-word phrase or idiom "{{str}}" for a language learner.
Target language: {{targetLang}}

Language policy:
{{languagePolicy}}

Formatting:
- Format using clear markdown subheadings (###) and bullet points. Do not use code fences or HTML.

### Meaning
Provide the natural translation into {{targetLang}} and explain the real-world idiomatic meaning, noting literal meaning only if it differs significantly.

### Usage and Register
Note formality (conversational, formal, idiom).

### Example
Give one realistic English sentence as a blockquote, then its {{targetLang}} translation as the next blockquote:
{{bilingualExampleShape}}

### Related Expressions
List 2-3 related idioms or phrases.
`,Bt=`# Master English Editor & IELTS Coach

You are a senior British editor and IELTS coach. Transform the source into polished English while keeping meaning, intent, tense, voice, named entities, numbers, and technical terms. Teach as you edit.

## Extension runtime

This prompt runs inside a Chrome extension rewriter. The user may paste a word, phrase, sentence, email draft, or short paragraph.

Source text to refine:
"""
{{sentence}}
"""
Optional surrounding context (do not rewrite this unless the source is only a fragment that needs it):
"""
{{context}}
"""
Target language for learner notes (Vietnamese glosses, vocabulary lab, translations): {{targetLang}}
Word count of source: {{word_count}}

Runtime rules:
- Never ask questions or wait for confirmation. Infer audience, document type, primary goal, and writing level from the source.
- Treat the source as writing to improve, not a dictionary headword. Rewrite the full supplied text.
- Preserve meaning. Do not invent facts or add a greeting/sign-off the source did not have.
- If a line in context starts with "Style:", bias register toward that request (formal, natural, concise, or casual) while still producing the full educational output.
- Default to Deep Dive. Use Quick Polish only for a single short sentence with no errors beyond spelling: revised blockquote + a 3-bullet Correctness / Clarity / Tone note. Skip remaining sections.
- Write learner-facing notes, vocabulary lab, and translations in {{targetLang}} where Vietnamese / target-language glosses are requested. Keep the refined English itself in English.
- Output Markdown only. Do not wrap the whole answer in a code fence.
- Use \`###\` for section headings and \`####\` for subsections. Headings are titles only \u2014 never prefix them with PHASE, numbers, or codes like \`3b\`.
- Do not use \`####\` without a space, and do not write heading markers as body text.
- Put the Revised Text in a blockquote (\`>\`). Use GitHub pipe tables for comparison tables. Use \`---\` only as a thematic break between subsections.

## Editor rules (internal \u2014 do not print)

- British English (\`organise\`, \`colour\`, \`centre\`, \`towards\`). Oxford comma only if it prevents ambiguity.
- Infer document type: Email, Technical, Academic/Formal, Casual, IELTS Practice, or General Text (default). Never ask.
- Diagnose first, then revise. Quote the source phrase for every issue. Severity: Critical / Moderate / Minor.
- Prefer active voice, cut redundancy, keep the author's voice unless it hurts clarity.
- Do not change technical jargon unless it is misspelled.
- Omit empty subsections. Skip IELTS Level Up unless the source is academic or exam-like. Skip Alternative Rewrite Options unless a sentence is genuinely ambiguous. Skip Pattern Analysis unless an error repeats.

## Output skeleton

Copy these headings verbatim. Fill with real findings from the source \u2014 never leave placeholders like \`[Specific Error]\`.

### \u{1F4CA} Diagnostic - Issues Identified FIRST

**Before corrections, here are the unclear or problematic areas found:**

#### \u{1F534} Correctness Issues
Group as Critical / Moderate / Minor. For each: quoted phrase, why, error type.

#### \u{1F7E1} Clarity Issues
Critical / Moderate. Quoted phrase, why, clarity score.

#### \u{1F7E2} Engagement Issues
High / Medium. Weak vocabulary or repetition, with an upgrade path.

#### \u{1F535} Delivery Issues
Tone or audience mismatch, only if present.

#### \u{1F537} Technical & Domain-Specific Terms (Preserved)
Only if technical terms appear.

### \u{1F4CA} Feedback Summary

- Document Type / Audience / Current Tone / Intended Tone
- Counts: Correctness, Clarity, Engagement, Delivery
- Estimated level and overall clarity score (before \u2192 after)

### \u{1F504} Tone Consistency Matrix

| Section | Current Tone | Intended Tone | Alignment | Adjustment |
| :--- | :--- | :--- | :--- | :--- |
| Opening | | | \u2705/\u274C | |
| Body | | | \u2705/\u274C | |
| Closing | | | \u2705/\u274C | |

### \u{1F58B}\uFE0F Revised Text (Professional Use)

> Fully polished ready-to-use text. Emails may include subject / greeting / closing only if the source already had them or clearly needs them.

### \u{1F4CA} Before/After Comparison Table

| Aspect | Original | Revised | Why Changed | Impact |
| :--- | :--- | :--- | :--- | :--- |
| Sentence / Vocabulary / Structure / Tone | | | | |

Keep to the 3\u20136 most important changes.

### \u{1F504} Alternative Rewrite Options

Only if a sentence is ambiguous. Option A (direct), B (formal), C (engaging). Each option is a blockquote plus one-line why / best-for. End with a recommendation.

### \u{1F680} IELTS "Level Up"

Only if academic or exam-like.

| Current (Band 6\u20137) | Band 8.0+ Alternative | Context & Usage | Why This Upgrade |
| :--- | :--- | :--- | :--- |
| | | | |

### \u{1F4A1} Key Improvements & Education

Logic & flow; British English conversions; then Vocabulary Lab:

| Word/Structure | {{targetLang}} Meaning | Oxford-style definition | Collocations | Reason Changed |
| :--- | :--- | :--- | :--- | :--- |
| | | | | |

### \u{1F393} Learning Moment, Pattern Analysis & Examiner's Tip

One grammar rule from the biggest error, with a correct example. Recurring patterns only if they exist. One IELTS progression tip if relevant.

### \u{1F3AF} Your Actionable Takeaway

Top 3 future fixes (watch-for / how-to-fix / example). One key habit in a blockquote.

## Quality bar

Every claim quotes the source. Explain why, not only what. Preserve original intent. If the source is unclear, give the most likely revision and add a **Clarification Note**.
`,qt=`- Write instructional explanations, definitions, grammar analyses, usage notes, and etymologies in English.
- Use {{targetLang}} only for translations, bilingual glosses, or when a section explicitly requests explanations in that language.
`,Ht=`> English sentence
> {{targetLang}} translation
`,Wt=`Use only Markdown headings at level 3 (###), short paragraphs, bullets, and blockquotes. Do not use HTML or code fences. Do not repeat headings.
`,zt=`Do not add Word Family, Related Forms, Derived Forms, Word Formation, Usage Warnings, Confusables, Common Learner Mistakes, Collocations, or Natural Collocations headings; reliable data for those categories belongs in the structured lexical profile.
`;String(qt).trim(),String(Ht).trim(),String(Wt).trim(),String(zt).trim();const xe=String(_t).trim(),$t=String(It).trim(),Kt=String(Rt).trim(),Gt=String(Ot).trim(),Yt=String(Dt).trim(),Xt=String(Nt).trim(),jt=String(Ut).trim();String(Ft).trim();const Vt=String(Bt).trim(),Zt={aiPromptTemplate:xe,aiDefaultPromptTemplate:xe,aiContextPromptTemplate:$t,aiGrammarPromptTemplate:Kt,aiSentencePromptTemplate:Xt,aiPhraseExplorerPromptTemplate:jt,aiComparePromptTemplate:Gt,aiRephrasePromptTemplate:Yt,aiRewritePromptTemplate:Vt},Qt=["aiApiKey","libreTranslateApiKey","aiRewritePromptTemplate"],Jt=["aiApiKey","libreTranslateApiKey"],Ee=new Set(Qt);new Set(Jt);const Se={theme:"dark",textSize:"comfortable",selectionTriggerMode:"icon",postSelectionModifier:"shift",enableContextMenuTrigger:!0,defaultTab:"dictionary",translateTargetLanguage:"Vietnamese",customLanguages:"Vietnamese, English, Chinese, Japanese, Korean, French, German, Spanish",translateProvider:"google",libreTranslateBaseUrl:"https://libretranslate.com",libreTranslateApiKey:"",dictionaryProvider:"wiktionary",popupWidth:1e3,popupHeight:900,enableTranslate:!0,enableDictionary:!0,enableLexicalProfile:!0,enableAI:!0,enableAiPreload:!1,persistLookupCache:!0,preloadedAiIntents:[],enablePhraseFallback:!0,disablePageContextExtraction:!1,pausedHostnames:[],pronunciationRate:.95,pronunciationVoiceURI:"",aiProvider:"gemini",aiBaseUrl:"https://generativelanguage.googleapis.com/v1beta/openai",aiApiKey:"",hasAiApiKey:!1,aiModel:"gemini-3.5-flash-lite",...Zt};[...Object.keys(Se).filter(e=>!Ee.has(e))];async function en(e){var o,a;if(typeof chrome>"u"||!chrome.storage)return;const t={},n={};for(const[s,p]of Object.entries(e))s in Se&&(Ee.has(s)||(t[s]=p),n[s]=p);if(Object.prototype.hasOwnProperty.call(n,"aiApiKey")){const s=!!String(n.aiApiKey??"").trim();t.hasAiApiKey=s,n.hasAiApiKey=s}else delete t.hasAiApiKey;const i=[];Object.keys(t).length&&((o=chrome.storage.sync)!=null&&o.set)&&i.push(chrome.storage.sync.set(t).catch(()=>{})),Object.keys(n).length&&((a=chrome.storage.local)!=null&&a.set)&&i.push(chrome.storage.local.set(n).catch(()=>{})),i.length&&await Promise.all(i)}const f={theme:"dark",textSize:"comfortable",dockPosition:"none",selectionTriggerMode:"icon",postSelectionModifier:"shift",pausedHostnames:[],popupWidth:1e3,popupHeight:900,disablePageContextExtraction:!1};function ve(e){return Array.isArray(e)?e.map(t=>String(t).trim().toLowerCase()).filter(Boolean):typeof e=="string"&&e.trim()?e.split(`
`).map(t=>t.trim().toLowerCase()).filter(Boolean):[]}function tn(e){const t=e.selectionTriggerMode,n=e.postSelectionModifier,i=e.dockPosition,o=String(e.theme||"").trim().toLowerCase(),a=String(e.textSize||"").trim().toLowerCase();return{theme:o==="light"||o==="system"?o:f.theme,textSize:a==="small"||a==="large"||a==="comfortable"?a:f.textSize,dockPosition:i==="left"||i==="right"?i:"none",selectionTriggerMode:t==="off"||t==="direct"||t==="icon"?t:f.selectionTriggerMode,postSelectionModifier:n==="alt"||n==="ctrl"||n==="shift"?n:f.postSelectionModifier,pausedHostnames:ve(e.pausedHostnames),popupWidth:Number(e.popupWidth)||f.popupWidth,popupHeight:Number(e.popupHeight)||f.popupHeight,disablePageContextExtraction:!!e.disablePageContextExtraction}}async function nn(){var e,t;if(typeof chrome>"u"||!chrome.storage)return{...f};try{const[n,i]=await Promise.all([(e=chrome.storage.sync)!=null&&e.get?chrome.storage.sync.get(f).catch(()=>({})):Promise.resolve({}),(t=chrome.storage.local)!=null&&t.get?chrome.storage.local.get(f).catch(()=>({})):Promise.resolve({})]),o={...f,...i||{},...n||{}};return tn(o)}catch{return{...f}}}function C(e,t,n){return Math.max(t,Math.min(e,n))}function rn(e,t,n,i=14,o=24){let a=e.x,s=e.y+i;return s+t.height>n.height-o&&(s=e.y-t.height-i),{left:C(a,o,n.width-t.width-o),top:C(s,o,n.height-t.height-o)}}function on(e,t,n,i,o=8){return{left:C(e.x+t.x,o,i.width-n.width-o),top:C(e.y+t.y,o,i.height-n.height-o)}}function an({viewport:e,event:t,selectionRect:n,iconSize:i=38,margin:o=10}){let a=e.width/2,s=e.height/2;return t&&typeof t.clientX=="number"?(a=t.clientX+12,s=t.clientY+8,a+i>e.width-o&&(a=t.clientX-i-12),s+i>e.height-o&&(s=t.clientY-i-8)):n&&(n.width||n.height)&&(a=n.right+o,s=n.top+Math.max(0,(n.height-i)/2),a+i>e.width-o&&(a=n.left-i-o),a<o&&(a=Math.max(o,Math.min(n.left,e.width-i-o)),s=n.bottom+o)),{x:C(a,o,e.width-i-o),y:C(s,o,e.height-i-o)}}const sn=`
.dictionary-trigger-icon-btn {
  position: fixed;
  z-index: 2147483646;
  width: 36px;
  height: 36px;
  border-radius: 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  -webkit-backdrop-filter: blur(20px) saturate(160%);
  backdrop-filter: blur(20px) saturate(160%);
  transition: transform 160ms cubic-bezier(0.16, 1, 0.3, 1), box-shadow 160ms ease, filter 160ms ease;
  outline: none;
  animation: dictionary-trigger-enter 220ms cubic-bezier(0.34, 1.56, 0.64, 1);
}
.dictionary-trigger-icon-btn:hover {
  transform: scale(1.08) translateY(-1px);
  filter: brightness(1.08);
}
.dictionary-trigger-icon-btn:active {
  transform: scale(0.93);
}
.dictionary-trigger-icon-btn:focus-visible {
  outline: 2.5px solid rgba(45, 212, 191, 0.85);
  outline-offset: 2.5px;
}
.dictionary-trigger-icon-btn.dark {
  background: linear-gradient(135deg, #0d9488 0%, #14b8a6 100%);
  color: #ffffff;
  border: 1px solid rgba(255, 255, 255, 0.28);
  box-shadow: 0 8px 20px -3px rgba(20, 184, 166, 0.45), 0 0 0 1px rgba(255, 255, 255, 0.15) inset;
}
.dictionary-trigger-icon-btn.light {
  background: linear-gradient(135deg, #0f766e 0%, #0d9488 100%);
  color: #ffffff;
  border: 1px solid rgba(255, 255, 255, 0.4);
  box-shadow: 0 8px 20px -3px rgba(13, 148, 136, 0.35), 0 1px 0 rgba(255, 255, 255, 0.4) inset;
}
.dictionary-trigger-icon-btn svg {
  filter: drop-shadow(0 1px 2px rgba(0, 0, 0, 0.25));
  transition: transform 180ms ease;
}
.dictionary-trigger-icon-btn:hover svg {
  transform: scale(1.08);
}
.dictionary-popup-layer {
  position: fixed;
  z-index: 2147483647;
  pointer-events: auto;
}
.dictionary-popup-layer > div {
  width: 100%;
  height: 100%;
}
.dictionary-popup-layer.maximized {
  inset: 1.25rem;
  display: flex;
  align-items: center;
  justify-content: center;
}
.dictionary-backdrop {
  position: fixed;
  inset: 0;
  z-index: 2147483646;
  background: rgba(15, 23, 42, 0.45);
  -webkit-backdrop-filter: blur(4px);
  backdrop-filter: blur(4px);
  animation: dictionary-backdrop-fade 180ms ease-out;
}
@media (prefers-reduced-transparency: reduce), (forced-colors: active) {
  .dictionary-trigger-icon-btn {
    -webkit-backdrop-filter: none;
    backdrop-filter: none;
  }
  .dictionary-backdrop {
    -webkit-backdrop-filter: none;
    backdrop-filter: none;
    background: rgba(15, 23, 42, 0.7);
  }
}
@keyframes dictionary-trigger-enter {
  0% { opacity: 0; transform: scale(0.65) translateY(4px); }
  70% { transform: scale(1.08) translateY(-1px); }
  100% { opacity: 1; transform: scale(1) translateY(0); }
}
@keyframes dictionary-backdrop-fade {
  from { opacity: 0; }
  to { opacity: 1; }
}
@media (prefers-reduced-motion: reduce) {
  .dictionary-trigger-icon-btn { animation: none; transition: none; }
  .dictionary-trigger-icon-btn:hover,
  .dictionary-trigger-icon-btn:active { transform: none; }
  .dictionary-backdrop { animation: none; }
}
`,Le="__dictionaryAssistantBoot";function ln(){const e=window;e[Le]||document.getElementById("dictionary-extension-root")||(e[Le]=!0,cn())}function cn(){var Ve,Ze,Qe,Je;let e=null,t={...f},n=null,i=null,o=0,a=!1,s=!1,p="none",m="",ge="",U="",Ce="",Me=null,Z=0,S=null,M=null,F=0,B=0,q=0,H=0,W=!1,_e=0,Ie=0,Re=0,Oe=0,v=!1,De=0,Ne=0,Ue=0,Fe=0,_=0,I=0,Q=0,J=0;Sn();function Be(r){if(W||v||!a||!e)return;const l=r.target;!e.host.contains(l)&&!e.shadow.contains(l)&&z()}function ee(){if(e)return e;const r=document.createElement("div");r.id="dictionary-extension-root",(document.body||document.documentElement).appendChild(r);const l=r.attachShadow({mode:"open"}),c=document.createElement("style");c.textContent=sn,l.appendChild(c);const d=document.createElement("button");d.type="button",d.title="Look up selection in Dictionary",d.className="dictionary-trigger-icon-btn dark",d.style.display="none";const u=document.createElementNS("http://www.w3.org/2000/svg","svg");u.setAttribute("width","18"),u.setAttribute("height","18"),u.setAttribute("viewBox","0 0 24 24"),u.setAttribute("fill","none"),u.setAttribute("stroke","currentColor"),u.setAttribute("stroke-width","2"),u.setAttribute("stroke-linecap","round"),u.setAttribute("stroke-linejoin","round"),u.setAttribute("aria-hidden","true");const h=document.createElementNS("http://www.w3.org/2000/svg","path");h.setAttribute("d","M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1-2.5-2.5Z");const L=document.createElementNS("http://www.w3.org/2000/svg","path");L.setAttribute("d","M6 6h10");const $=document.createElementNS("http://www.w3.org/2000/svg","path");$.setAttribute("d","M6 10h7");const R=document.createElementNS("http://www.w3.org/2000/svg","path");R.setAttribute("d","m17 7 1 2 2 1-2 1-1 2-1-2-2-1 2-1 1-2Z"),R.setAttribute("fill","currentColor"),R.setAttribute("stroke","none"),u.appendChild(h),u.appendChild(L),u.appendChild($),u.appendChild(R),d.appendChild(u),l.appendChild(d);const T=document.createElement("div");T.className="dictionary-backdrop",T.style.display="none",l.appendChild(T);const k=document.createElement("div");k.className="dictionary-popup-layer",k.style.display="none";const O=document.createElement("div");return O.setAttribute("role","presentation"),k.appendChild(O),l.appendChild(k),d.addEventListener("click",K=>{K.preventDefault(),K.stopPropagation(),m&&ye(q,H,m)}),T.addEventListener("click",()=>{s&&$e()}),e={host:r,shadow:l,triggerBtn:d,backdrop:T,popupLayer:k,overlayMount:O},ne(),e}function te(){e&&(e.triggerBtn.style.display="none")}function mn(){var r;return t.theme==="system"?((r=window.matchMedia)==null?void 0:r.call(window,"(prefers-color-scheme: dark)").matches)??!0:t.theme!=="light"}function ne(){if(!e)return;const r=mn(),l=t.textSize||"comfortable",{host:c,triggerBtn:d,popupLayer:u,overlayMount:h}=e;d.classList.toggle("dark",r),d.classList.toggle("light",!r),c.setAttribute("data-theme",r?"dark":"light"),c.setAttribute("data-text-size",l),c.classList.toggle("dark",r),c.classList.toggle("light",!r),u.setAttribute("data-theme",r?"dark":"light"),u.setAttribute("data-text-size",l),u.classList.toggle("dark",r),u.classList.toggle("light",!r),h.setAttribute("data-theme",r?"dark":"light"),h.setAttribute("data-text-size",l),h.classList.toggle("dark",r),h.classList.toggle("light",!r)}function fe(){const r=location.hostname.toLowerCase();return t.pausedHostnames.includes(r)}function ie(){return{width:S||t.popupWidth||f.popupWidth,height:M||t.popupHeight||f.popupHeight}}function qe(r,l){e&&(S=r,M=l,e.popupLayer.style.width=`${r}px`,e.popupLayer.style.height=`${l}px`)}function He(r,l){const{popupLayer:c}=ee(),{width:d,height:u}=ie(),h=rn({x:r,y:l},{width:d,height:u},{width:window.innerWidth,height:window.innerHeight});F=h.left,B=h.top,c.style.left=`${h.left}px`,c.style.top=`${h.top}px`,c.style.width=`${d}px`,c.style.height=`${u}px`}function me(r){if(!(!r||r.rangeCount<=0))try{const l=r.getRangeAt(0).cloneRange();l.toString().trim()&&(Me=l)}catch{}}function yn(r){return xt(r,t.disablePageContextExtraction,Me).context||""}function We(r){return r.length<2||!/[A-Za-z\u00C0-\u024F\u1E00-\u1EFF]/.test(r)}function wn(){if(P())return Promise.reject(new Error("Extension was reloaded. Refresh this page to continue."));const{shadow:r}=ee();if(!i)try{if(!r.querySelector("[data-dict-overlay-css]")){const c=document.createElement("link");c.rel="stylesheet",c.dataset.dictOverlayCss="true",c.href=chrome.runtime.getURL("assets/overlay.css"),r.appendChild(c)}i=import(chrome.runtime.getURL("assets/overlay-app.js")).then(()=>{const c=globalThis;if(!c.__dictionaryAssistantOverlay)throw new Error("Overlay runtime failed to initialize.");return c.__dictionaryAssistantOverlay})}catch(l){if(P(l))return Promise.reject(new Error("Extension was reloaded. Refresh this page to continue."));throw l}return i}function re(){return{selectedText:m,contextSentence:ge,lookupRequestId:U||void 0,isMaximized:s,dockPosition:p}}function ze(){n==null||n.unmount(),n=null}async function ye(r,l,c,d){if(fe())return;const u=String(c||"").trim();if(!u)return;const{shadow:h,triggerBtn:L,popupLayer:$,overlayMount:R,backdrop:T}=ee(),k=++o;ne(),L.style.display="none",m=u,Ce=u,ge=String(d||"").trim()||yn(u),U=le("dict"),He(r,l),a=!0,window.addEventListener("click",Be,!0),s=!1,$.classList.remove("maximized"),$.style.display="block",T.style.display="none",Ct({text:u,context:ge||void 0,requestId:U}).catch(()=>{});let O;try{O=await wn()}catch(K){if(P(K)){z();return}throw K}!a||k!==o||(n?n.update(re()):n=O.mountOverlay(h,R,re(),{onClose:z,onToggleMaximize:$e,onToggleDock:bn,onStartDrag:xn,onStartResize:En}))}function z(){window.removeEventListener("click",Be,!0),o+=1;const r=U;a=!1,s=!1,p="none",U="",e&&(e.popupLayer.classList.remove("docked-left","docked-right"),e.triggerBtn.style.display="none",e.popupLayer.style.display="none",e.backdrop.style.display="none",e.popupLayer.classList.remove("maximized")),ze(),r&&Pt(r)}function bn(){if(!e)return;const{popupLayer:r}=e;p==="none"?(p="right",r.classList.add("docked-right"),r.classList.remove("docked-left","maximized"),r.style.left="",r.style.top="0",r.style.width="420px",r.style.height="100vh",s=!1):(p="none",r.classList.remove("docked-left","docked-right"),He(window.innerWidth-(S||480)-24,60)),n==null||n.update(re())}function $e(){if(!e)return;const{popupLayer:r,backdrop:l}=e;s=!s,s&&(p="none",r.classList.remove("docked-left","docked-right")),r.classList.toggle("maximized",s),r.style.left=s?"":`${F}px`,r.style.top=s?"":`${B}px`,l.style.display=s?"block":"none",n==null||n.update(re())}function xn(r){s||!e||(W=!0,_e=r.clientX,Ie=r.clientY,Re=F,Oe=B,e.popupLayer.style.willChange="left, top",window.addEventListener("mousemove",Ke,{passive:!0}),window.addEventListener("mouseup",Ge))}function Ke(r){!W||!e||(Q=r.clientX,J=r.clientY,!_&&(_=requestAnimationFrame(()=>{if(_=0,!W||!e)return;const{width:l,height:c}=ie(),d=on({x:Re,y:Oe},{x:Q-_e,y:J-Ie},{width:l,height:c},{width:window.innerWidth,height:window.innerHeight});F=d.left,B=d.top,e.popupLayer.style.left=`${d.left}px`,e.popupLayer.style.top=`${d.top}px`})))}function Ge(){W=!1,_&&(cancelAnimationFrame(_),_=0),e&&(e.popupLayer.style.willChange="auto"),window.removeEventListener("mousemove",Ke),window.removeEventListener("mouseup",Ge)}function En(r){if(s||!e)return;v=!0,De=r.clientX,Ne=r.clientY;const l=ie();Ue=l.width,Fe=l.height,e.popupLayer.style.willChange="width, height",window.addEventListener("mousemove",Ye,{passive:!0}),window.addEventListener("mouseup",Xe)}function Ye(r){v&&(Q=r.clientX,J=r.clientY,!I&&(I=requestAnimationFrame(()=>{if(I=0,!v)return;const l=Math.max(360,Math.min(window.innerWidth-F-16,Ue+(Q-De))),c=Math.max(380,Math.min(window.innerHeight-B-16,Fe+(J-Ne)));qe(l,c)})))}function Xe(){I&&(cancelAnimationFrame(I),I=0),v&&S&&M&&(t.popupWidth=S,t.popupHeight=M,en({popupWidth:S,popupHeight:M})),v=!1,e&&(e.popupLayer.style.willChange="auto"),window.removeEventListener("mousemove",Ye),window.removeEventListener("mouseup",Xe)}function je(r){if(fe()){te();return}const l=window.getSelection(),c=l==null?void 0:l.toString().trim();if(!c||We(c)){te();return}const d=t.selectionTriggerMode||"icon";if(d==="off")return;me(l),m=c;const{triggerBtn:u}=ee(),h=l&&l.rangeCount>0?l.getRangeAt(0).getBoundingClientRect():void 0,L=an({viewport:{width:window.innerWidth,height:window.innerHeight},event:r&&typeof r.clientX=="number"?r:void 0,selectionRect:h});if(q=L.x,H=L.y,d==="direct"){if(c.length>80){u.style.left=`${q}px`,u.style.top=`${H}px`,u.style.display=a?"none":"flex";return}if(a&&Ce===c)return;ye(q,H,c);return}u.style.left=`${q}px`,u.style.top=`${H}px`,u.style.display=a?"none":"flex"}window.addEventListener("mouseup",r=>{if(fe()||(t.selectionTriggerMode||"icon")==="off"||e&&(e.host.contains(r.target)||e.shadow.contains(r.target)))return;const l=window.getSelection();if(!l||l.isCollapsed){te();return}const c=l.toString().trim();if(!c||We(c)){te();return}me(l),Z&&cancelAnimationFrame(Z),Z=requestAnimationFrame(()=>{Z=0,je(r)})},{passive:!0}),window.addEventListener("keydown",r=>{var h;if(r.key==="Escape"){a&&(r.preventDefault(),z());return}if(r.key!=="q"&&r.key!=="Q")return;const l=r.target;if(l instanceof HTMLInputElement||l instanceof HTMLTextAreaElement||l.isContentEditable)return;const c=t.postSelectionModifier||"shift";if(!(c==="shift"&&r.shiftKey||c==="alt"&&r.altKey||c==="ctrl"&&(r.ctrlKey||r.metaKey)))return;((h=window.getSelection())==null?void 0:h.toString().trim())&&(je(),r.preventDefault())}),(Ze=(Ve=chrome.runtime)==null?void 0:Ve.onMessage)==null||Ze.addListener(r=>{const l=r.payload||{};if(!(r.type==="OPEN_LOOKUP_POPUP"||r.type==="DICTIONARY_LOOKUP"))return;const d=window.getSelection(),u=String(l.text||r.text||"").trim()||(l.fromSelection||!r.text?d==null?void 0:d.toString().trim():"")||"";u&&(me(d),ye(window.innerWidth/2-220,60,u,l.context))}),window.addEventListener("pagehide",()=>{z(),ze()}),(Je=(Qe=chrome.storage)==null?void 0:Qe.onChanged)==null||Je.addListener((r,l)=>{if(!(l!=="sync"&&l!=="local")){for(const[c,d]of Object.entries(r))c in t&&(t[c]=d.newValue);if(t.pausedHostnames=ve(t.pausedHostnames),t.popupWidth=Number(t.popupWidth)||f.popupWidth,t.popupHeight=Number(t.popupHeight)||f.popupHeight,ne(),("popupWidth"in r||"popupHeight"in r)&&(v||(S=null,M=null),a&&!s&&e)){const{width:c,height:d}=ie();qe(c,d)}}});async function Sn(){t=await nn(),ne()}}const un={matches:["<all_urls>"],runAt:"document_idle",cssInjectionMode:"manual",main(){ln()}};function X(e,...t){}const dn={debug:(...e)=>X(console.debug,...e),log:(...e)=>X(console.log,...e),warn:(...e)=>X(console.warn,...e),error:(...e)=>X(console.error,...e)},j=(Ae=(ke=globalThis.browser)==null?void 0:ke.runtime)!=null&&Ae.id?globalThis.browser:globalThis.chrome;var Te=(E=class extends Event{constructor(t,n){super(E.EVENT_NAME,{}),this.newUrl=t,this.oldUrl=n}},D(E,"EVENT_NAME",pe("wxt:locationchange")),E);function pe(e){var t;return`${(t=j==null?void 0:j.runtime)==null?void 0:t.id}:content:${e}`}const hn=typeof((Pe=globalThis.navigation)==null?void 0:Pe.addEventListener)=="function";function pn(e){let t,n=!1;return{run(){n||(n=!0,t=new URL(location.href),hn?globalThis.navigation.addEventListener("navigate",i=>{const o=new URL(i.destination.url);o.href!==t.href&&(window.dispatchEvent(new Te(o,t)),t=o)},{signal:e.signal}):e.setInterval(()=>{const i=new URL(location.href);i.href!==t.href&&(window.dispatchEvent(new Te(i,t)),t=i)},1e3))}}}var gn=(w=class{constructor(t,n){D(this,"id");D(this,"abortController");D(this,"locationWatcher",pn(this));this.contentScriptName=t,this.options=n,this.id=Math.random().toString(36).slice(2),this.abortController=new AbortController,this.stopOldScripts(),this.listenForNewerScripts()}get signal(){return this.abortController.signal}abort(t){return this.abortController.abort(t)}get isInvalid(){var t;return((t=j.runtime)==null?void 0:t.id)==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(t){return this.signal.addEventListener("abort",t),()=>this.signal.removeEventListener("abort",t)}block(){return new Promise(()=>{})}setInterval(t,n){const i=setInterval(()=>{this.isValid&&t()},n);return this.onInvalidated(()=>clearInterval(i)),i}setTimeout(t,n){const i=setTimeout(()=>{this.isValid&&t()},n);return this.onInvalidated(()=>clearTimeout(i)),i}requestAnimationFrame(t){const n=requestAnimationFrame((...i)=>{this.isValid&&t(...i)});return this.onInvalidated(()=>cancelAnimationFrame(n)),n}requestIdleCallback(t,n){const i=requestIdleCallback((...o)=>{this.signal.aborted||t(...o)},n);return this.onInvalidated(()=>cancelIdleCallback(i)),i}addEventListener(t,n,i,o){var a;n==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),(a=t.addEventListener)==null||a.call(t,n.startsWith("wxt:")?pe(n):n,i,{...o,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),dn.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){var t;document.dispatchEvent(new CustomEvent(w.SCRIPT_STARTED_MESSAGE_TYPE,{detail:{contentScriptName:this.contentScriptName,messageId:this.id}})),(t=this.options)!=null&&t.noScriptStartedPostMessage||window.postMessage({type:w.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:this.id},"*")}verifyScriptStartedEvent(t){var o,a;const n=((o=t.detail)==null?void 0:o.contentScriptName)===this.contentScriptName,i=((a=t.detail)==null?void 0:a.messageId)===this.id;return n&&!i}listenForNewerScripts(){const t=n=>{!(n instanceof CustomEvent)||!this.verifyScriptStartedEvent(n)||this.notifyInvalidated()};document.addEventListener(w.SCRIPT_STARTED_MESSAGE_TYPE,t),this.onInvalidated(()=>document.removeEventListener(w.SCRIPT_STARTED_MESSAGE_TYPE,t))}},D(w,"SCRIPT_STARTED_MESSAGE_TYPE",pe("wxt:content-script-started")),w);function Mn(){}function V(e,...t){}const fn={debug:(...e)=>V(console.debug,...e),log:(...e)=>V(console.log,...e),warn:(...e)=>V(console.warn,...e),error:(...e)=>V(console.error,...e)};return(async()=>{try{const{main:e,...t}=un;return await e(new gn("content",t))}catch(e){throw fn.error('The content script "content" crashed on startup!',e),e}})()})();
